package stepDefinition;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PostOperation {
	int status;

	@Given("Post user details into the list")
	public void post_user_details_into_the_list() {
		System.out.println("Adding users details into the list");
	}

	@When("Add user name and job details")
	public void add_user_name_and_job_details() {
		PropertyConfigurator.configure("C:\\SHALOM\\workspace\\Cucumber\\src\\log4j.properties");
		Logger log = Logger.getLogger("devpinoyLogger");
		log.info("Method:Creating user details in List");
		log.debug("Hello Log4J from Logger as Debug");
		RestAssured.baseURI = "https://reqres.in/api/users";
		JSONObject requestparams = new JSONObject();
		log.info("Adding User Name and Job details into List");
		requestparams.put("name", "Jicky");
		requestparams.put("job", "Developer");
		RequestSpecification request = RestAssured.given();
		request.body(requestparams);
		Response response = request.post("https://reqres.in/api/users");
		System.out.println("Name: " + requestparams.get("name"));
		System.out.println("job: " + requestparams.get("job"));
		response.prettyPrint();
		System.out.println("The status code is " + response.getStatusCode());
		log.info("Post Operation has been handled");
	}

	@Then("Should get user id detail and success status code")
	public void should_get_user_id_detail_and_success_status_code() {
		System.out.println("The status code is " + status);
	}
}
