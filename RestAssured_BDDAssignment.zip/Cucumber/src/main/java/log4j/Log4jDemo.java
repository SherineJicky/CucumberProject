package log4j;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Log4jDemo {
	public static void main(String[] args) {
		//To specify Properties location for log4j
		PropertyConfigurator.configure("C:\\SHALOM\\workspace\\Cucumber\\src\\log4j.properties");
		//Creating instance of logger
		Logger log=Logger.getLogger("devpinoyLogger");
		System.out.println("Hello Log4J");
		log.info("Hello Log4J from Logger as info");
		log.debug("Hello Log4J from Logger as Debug");
	}

}
