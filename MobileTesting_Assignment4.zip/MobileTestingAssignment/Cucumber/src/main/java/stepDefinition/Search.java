package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Search {

	WebDriver wd;

	@Given("I want to open google home page {string}")
	public void i_want_to_open_google_home_page(String string) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\SHALOM\\SELENIUM\\chromedriver.exe");
		wd = new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.google.com/");
		Thread.sleep(2000);
	}

	@When("I type {string} and click on Search button")
	public void i_type_and_click_on_search_button(String string) throws InterruptedException {
        wd.findElement(By.name("q")).sendKeys(string + Keys.ENTER);
        Thread.sleep(2000);
	}

	@Then("I should open the first link")
	public void i_should_open_the_first_link() throws InterruptedException {
        System.out.println("First link is" + wd.findElement(By.xpath("(//a/h3)[1]")).getText());
        wd.findElement(By.xpath("(//a/h3)[1]")).click();
        Thread.sleep(5000);
        wd.close();
	}

}
