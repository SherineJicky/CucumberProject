package stepDefinition;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PutOperation {
	int status;

	@Given("Update user details into the list")
	public void update_user_details_into_the_list() {
		System.out.println("Updating users details into the list");
	}

	@When("Update user name and job details")
	public void update_user_name_and_job_details() {
		PropertyConfigurator.configure("C:\\SHALOM\\workspace\\Cucumber\\src\\log4j.properties");
		Logger log = Logger.getLogger("devpinoyLogger");
		log.info("Method:Updating user details into List");
		log.debug("Hello Log4J from Logger as Debug");
		JSONObject requestparams = new JSONObject();
		log.info("Updating User Name and Job details into List");
		requestparams.put("name", "Sherine");
		requestparams.put("job", "Tester");
		RequestSpecification request = RestAssured.given();
		request.body(requestparams);
		Response response = request.put("https://reqres.in/api/users");
		System.out.println("Name: " + requestparams.get("name"));
		System.out.println("job: " + requestparams.get("job"));
		response.prettyPrint();
		System.out.println("The status code is " + response.getStatusCode());
		log.info("Put Operation has been handled");
	}

	@Then("User should get updated detail and success status code")
	public void user_should_get_updated_detail_and_success_status_code() {
		System.out.println("The status code is " + status);
	}

}
