package stepDefinition;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteOperation {
	int status;
	@Given("To delete user details from API")
	public void to_delete_user_details_from_api() {
		System.out.println("Deleting users details from the list"); 
	}

	@When("Delete user details with id")
	public void delete_user_details_with_id() {
		PropertyConfigurator.configure("C:\\SHALOM\\workspace\\Cucumber\\src\\log4j.properties");
		Logger log=Logger.getLogger("devpinoyLogger");
		log.info("Method:Deleting user details from List");
		log.debug("Hello Log4J from Logger as Debug");
		Response resp=RestAssured.given()
				.delete("https://reqres.in/api/users2");
		resp.prettyPrint();
		System.out.println("The status code is " +resp.getStatusCode());
		log.info("Delete Operation has been handled");
	    
	}

	@Then("User details should get delete and get success status code")
	public void user_details_should_get_delete_and_get_success_status_code() {
		System.out.println("The status code is " +status);
	}

}
