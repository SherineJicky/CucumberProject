package Assignment3.RestAPI_BDD;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Get {
	
@Test
public void getUsersList() {
	
	PropertyConfigurator.configure("C:\\SHALOM\\workspace\\Cucumber\\src\\log4j.properties");
	Logger log=Logger.getLogger("devpinoyLogger");
	log.info("Method:Getting User List");
	log.debug("Hello Log4J from Logger as Debug");
	Response resp=RestAssured.given()
			.get("https://reqres.in/api/users?page=2");
			resp.prettyPrint();
			System.out.println("The status code is "+ resp.getStatusCode());
			log.info("Get Operation has been handled");

}
}
