package Assignment3.RestAPI_BDD;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Put {

	@Test
	public void updateUserDetailsintoList() {
		PropertyConfigurator.configure("C:\\SHALOM\\workspace\\Cucumber\\src\\log4j.properties");
		Logger log = Logger.getLogger("devpinoyLogger");
		log.info("Method:Updating user details into List");
		log.debug("Hello Log4J from Logger as Debug");
		JSONObject requestparams = new JSONObject();

		log.info("Updating User Name and Job details into List");
		requestparams.put("name", "Sherine");
		requestparams.put("job", "Tester");
		RequestSpecification request = RestAssured.given();
		request.body(requestparams);
		Response response = request.put("https://reqres.in/api/users/2");
		System.out.println("Name: " + requestparams.get("name"));
		System.out.println("job: " + requestparams.get("job"));
		response.prettyPrint();
		System.out.println("The status code is " + response.getStatusCode());
		log.info("Put Operation has been handled");
	}
}
