package Assignment4.Appium;

import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class Case4 extends BaseSet {

	@Test
	public void case4() throws MalformedURLException, InterruptedException {
		Screen_Page page = new Screen_Page();
		TouchAction touch = new TouchAction(BaseSet.driver);
		touch.tap(tapOptions().withElement(element(page.viewlistElement.get(11)))).perform();
		Thread.sleep(2000);
		System.out.println("Done selecting viewer");
		TouchAction touch1 = new TouchAction(BaseSet.driver);
		touch1.tap(tapOptions().withElement(element(page.ExpandablelistElement.get(8)))).perform();
		System.out.println("Done Expandable List");
		TouchAction touch2 = new TouchAction(driver);
		touch2.tap(tapOptions().withElement(element(page.CustomAdapterlistElement.get(0)))).perform();
		System.out.println("done Custom Adapter");

		for (MobileElement eachElement : (List<MobileElement>) page.ExpandablelistElement) {
			System.out.println(eachElement.getAttribute("text"));
		}

		TouchAction touch3 = new TouchAction(driver);
		String peopleNamesXPATH = "//*[@text='People Names']";
		String dogNamesXPATH = "//*[@text='Dog Names']";
		String catNamesXPATH = "//*[@text='Cat Names']";
		String fishNamesXPATH = "//*[@text='Fish Names']";

		touch3.tap(tapOptions().withElement(element((MobileElement) page.PeopleNames))).perform();

		for (MobileElement peopleNames : page.ExpandablelistElement) {
			if (peopleNames.getAttribute("text").equals("Sherine"))
				System.out.println("Sherine is verified");
			if (peopleNames.getAttribute("text").equals("Shero"))
				System.out.println("Shero is verified");
			if (peopleNames.getAttribute("text").equals("Jicky"))
				System.out.println("Jicky is verified");
			if (peopleNames.getAttribute("text").equals("Simon"))
				System.out.println("Simon is verified");
		}

		touch3.tap(tapOptions().withElement(element((MobileElement) page.PeopleNames))).perform();

		touch3.tap(tapOptions().withElement(element((MobileElement) page.dogNames))).perform();

		for (MobileElement dogNames : page.ExpandablelistElement) {
			if (dogNames.getAttribute("text").equals("Retriever"))
				System.out.println("Retriever is verified");
			if (dogNames.getAttribute("text").equals("Lab"))
				System.out.println("Lab is verified");
			if (dogNames.getAttribute("text").equals("GermanShepherd"))
				System.out.println("GermanShepherd is verified");
			if (dogNames.getAttribute("text").equals("Bruno"))
				System.out.println("Bruno is verified");
		}

		touch3.tap(tapOptions().withElement(element((MobileElement) page.dogNames))).perform();

		touch3.tap(tapOptions().withElement(element((MobileElement) page.catNames))).perform();

		for (MobileElement catNames : page.ExpandablelistElement) {
			if (catNames.getAttribute("text").equals("Brownie"))
				System.out.println("Brownie is verified");
			if (catNames.getAttribute("text").equals("Simran"))
				System.out.println("Simran is verified");
		}

		touch3.tap(tapOptions().withElement(element((MobileElement) page.catNames))).perform();

		touch3.tap(tapOptions().withElement(element((MobileElement) page.fishNames))).perform();

		for (MobileElement fishNames : page.ExpandablelistElement) {
			if (fishNames.getAttribute("text").equals("Shark"))
				System.out.println("Shark is verified");
			if (fishNames.getAttribute("text").equals("Nemo"))
				System.out.println("Nemo is verified");
		}

		touch3.tap(tapOptions().withElement(element((MobileElement) page.fishNames))).perform();

		System.out.println("Test Case4 executed successfully");

	}

}
